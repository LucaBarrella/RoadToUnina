# 🖥️ RoadToUnina — Front-end Single Page Application (SPA)

[![Live App](https://img.shields.io/badge/Live_App-road--to--unina.vercel.app-FF007A?style=for-the-badge&logo=vercel&logoColor=white)](https://road-to-unina.vercel.app)
[![React](https://img.shields.io/badge/React-v18.3-61DAFB?style=for-the-badge&logo=react&logoColor=black)](https://react.dev/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-Neo--Brutalist-38BDF8?style=for-the-badge&logo=tailwindcss&logoColor=white)](https://tailwindcss.com/)
[![Playwright Tests](https://img.shields.io/badge/Playwright_E2E-20%2F20%20Passing%20(100%25)-2EAD33?style=for-the-badge&logo=playwright&logoColor=white)](#-test-end-to-end-playwright)

Single Page Application (SPA) reattiva per il gioco di speedrunning enciclopedico **RoadToUnina**, realizzata con **React 18**, **TypeScript**, **Vite**, **Tailwind CSS** con design system **Neo-Brutalism** personalizzato.

---

## 🎨 Design System: Neo-Brutalism Personalizzato

L'interfaccia utente adotta uno stile grafico Neo-Brutalist moderno, accessibile e distintivo:
- **Palette Colori HSL**: Giallo Unina (`#FFE600`), Ciano Elettrico (`#00F0FF`), Rosa Fluo (`#FF2E93`), Nero Puro (`#000000`) e Bianco Superficie (`#FFFFFF`).
- **Ombre Hard Shadow**: `shadow-neo` (`4px 4px 0px #000000`) e `shadow-neo-lg` (`8px 8px 0px #000000`).
- **Bordi Decisi**: Bordi spessi da 3px (`border-3 border-neo-black`).
- **Tipografia**: Font Google *Space Grotesk* per titoli e accenti, *Inter* per testi enciclopedici, *JetBrains Mono* per timer, click e rank.

---

## 🚀 Avvio Locale

```bash
# 1. Accedi alla cartella frontend
cd frontend

# 2. Installa le dipendenze
npm install

# 3. Avvia il server di sviluppo Vite
npm run dev
```

L'applicazione sarà accessibile su: **`http://localhost:5173`**.

---

## 🧪 Test End-to-End (Playwright — 20 Test)

Il frontend include **20 test E2E automatizzati** che simulano le azioni reali del browser:

```bash
# Esegui tutti i 20 test E2E
npx playwright test

# Esegui con interfaccia grafica interattiva
npx playwright test --ui

# Esegui le speedrun tematiche (Boris, antirez, Local LLMs, Maradona, Pizza, Totò)
npx playwright test e2e/thematic-speedruns.spec.ts

# Esegui i test di persistenza sessione e accessibilità UX
npx playwright test e2e/ux-accessibility.spec.ts
```

---

## 📁 Struttura della Directory

```
frontend/
├── e2e/                     # Suite di test Playwright E2E (20 test)
│   ├── gameplay.spec.ts     # Test gameplay, registrazione, login e anti-cheat
│   ├── thematic-speedruns.spec.ts # Speedrun tematiche (Boris, antirez, AI, Totò, ecc.)
│   ├── ux-accessibility.spec.ts   # Session persistence, guest mode, keyboard e accessibilità
│   ├── speedrun-moonknight.spec.ts# Playtest speedrun Moon Knight -> Unina
│   ├── live-verification.spec.ts  # Test error recovery e resilienza
│   └── production-full.spec.ts    # Test navigazione e integrazione completa
├── public/                  # Asset statici e favicon
├── src/
│   ├── api/                 # Client Axios centralizzato (auth, game, public)
│   ├── components/
│   │   ├── game/            # Componenti di gioco (HUDBar, WikiRenderer)
│   │   └── ui/              # Componenti Neo-Brutalist (Button, Card, Navbar, Toast)
│   ├── hooks/               # Custom Hooks (useAuth, useGameEngine, useLeaderboard)
│   ├── pages/               # Viste SPA (HomePage, GamePage, LeaderboardPage, LoginPage, RegisterPage)
│   ├── styles/              # Token e classi CSS Neo-Brutalism
│   └── types/               # Definizioni TypeScript per API, entità e stato
├── Dockerfile               # Configurazione multi-stage con Nginx alpine
├── nginx.conf               # Configurazione Nginx con reverse proxy API
├── package.json             # Descrittore dipendenze e script npm
└── vite.config.ts           # Configurazione bundler Vite
```
